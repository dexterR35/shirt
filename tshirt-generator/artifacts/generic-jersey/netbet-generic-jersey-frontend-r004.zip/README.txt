Frontend review package: 52 transparent PNG/WebP assets and usage specifications.
8K masters, editable paint and proofs are in netbet-generic-jersey-r004.zip.
UX Lead approval and raster-format agreement are pending; no release approval is implied.
